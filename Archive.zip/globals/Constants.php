<?php

/**
 * Created by PhpStorm.
 * User: jamesskywalker
 * Date: 30/03/2020
 * Time: 19:04
 */
class Constants {

    const ACTIVE_QUIZ = 'ACTIVE_QUIZ';
    const ROOT = 'http://localhost/quizatthedicks/';
}